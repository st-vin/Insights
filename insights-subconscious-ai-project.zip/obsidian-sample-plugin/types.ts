export interface DocumentMetadata {
	filePath: string;
	title: string;
	modifiedEpochMs: number;
	wordCount: number;
	sentimentScore: number; // range approximately [-1, 1]
}

export interface TokenStatistics {
	documentFrequency: number;
	totalTermFrequency: number;
}

export interface InvertedPosting {
	documentPath: string;
	termFrequency: number;
}

export interface InvertedIndex {
	[token: string]: InvertedPosting[];
}

export interface TfIdfVector {
	[token: string]: number;
}

export interface IndexedDocument {
	meta: DocumentMetadata;
	vector: TfIdfVector;
}

export interface IndexSnapshot {
	documents: Record<string, IndexedDocument>; // key: filePath
	inverted: InvertedIndex;
	tokenStats: Record<string, TokenStatistics>;
	totalDocuments: number;
}

export interface SearchResult {
	filePath: string;
	title: string;
	excerpt: string;
	score: number;
	similarity: number;
	recencyBoost: number;
	sentimentBoost: number;
}

export type EmbeddingProviderType = 'tfidf-local' | 'openai';

export interface InsightsSettings {
	provider: EmbeddingProviderType;
	openAIApiKey: string;
	indexOnStartup: boolean;
	autoUpdateOnFileChange: boolean;
	recencyHalfLifeDays: number; // for decay weighting
	maxSearchResults: number;
}

export const DEFAULT_INSIGHTS_SETTINGS: InsightsSettings = {
	provider: 'tfidf-local',
	openAIApiKey: '',
	indexOnStartup: true,
	autoUpdateOnFileChange: true,
	recencyHalfLifeDays: 30,
	maxSearchResults: 20,
};