import { App, TFile } from 'obsidian';
import { tokenize } from './tokenize';
import { DEFAULT_INSIGHTS_SETTINGS, DocumentMetadata, IndexSnapshot, IndexedDocument, InsightsSettings, SearchResult, TfIdfVector } from './types';

export class VaultIndexer {
	private app: App;
	private settings: InsightsSettings;
	private snapshot: IndexSnapshot;

	constructor(app: App, settings: InsightsSettings) {
		this.app = app;
		this.settings = settings;
		this.snapshot = {
			documents: {},
			inverted: {},
			tokenStats: {},
			totalDocuments: 0,
		};
	}

	getSnapshot(): IndexSnapshot {
		return this.snapshot;
	}

	async indexAllMarkdown(): Promise<void> {
		const files = this.app.vault.getMarkdownFiles();
		const docs: Record<string, IndexedDocument> = {};
		const inverted: IndexSnapshot['inverted'] = {};
		const tokenDocFreq: Record<string, Set<string>> = {};

		for (const file of files) {
			const content = await this.app.vault.cachedRead(file);
			const tokens = tokenize(content);
			const termCounts: Record<string, number> = {};
			for (const tok of tokens) {
				termCounts[tok] = (termCounts[tok] || 0) + 1;
			}

			const vector: TfIdfVector = {};
			const totalTerms = tokens.length || 1;
			for (const [tok, count] of Object.entries(termCounts)) {
				const tf = count / totalTerms;
				vector[tok] = tf; // idf applied later after we know corpus stats
				if (!tokenDocFreq[tok]) tokenDocFreq[tok] = new Set();
				tokenDocFreq[tok].add(file.path);
			}

			const meta: DocumentMetadata = {
				filePath: file.path,
				title: this.deriveTitle(file, content),
				modifiedEpochMs: file.stat.mtime,
				wordCount: totalTerms,
				sentimentScore: this.estimateSentiment(content),
			};

			docs[file.path] = { meta, vector };
		}

		const totalDocuments = Object.keys(docs).length || 1;

		// compute idf
		const idf: Record<string, number> = {};
		for (const [tok, docSet] of Object.entries(tokenDocFreq)) {
			const df = docSet.size;
			idf[tok] = Math.log((1 + totalDocuments) / (1 + df)) + 1;
		}

		// apply tf-idf and build inverted index
		for (const [path, doc] of Object.entries(docs)) {
			for (const [tok, tfVal] of Object.entries(doc.vector)) {
				const weight = tfVal * (idf[tok] || 1);
				doc.vector[tok] = weight;
				if (!inverted[tok]) inverted[tok] = [];
				inverted[tok].push({ documentPath: path, termFrequency: weight });
			}
		}

		this.snapshot = {
			documents: docs,
			inverted,
			tokenStats: Object.fromEntries(Object.entries(tokenDocFreq).map(([t, set]) => [t, { documentFrequency: set.size, totalTermFrequency: inverted[t].reduce((a, b) => a + b.termFrequency, 0) } ])),
			totalDocuments,
		};
	}

	private deriveTitle(file: TFile, content: string): string {
		const m = content.match(/^#\s+(.+)$/m);
		return m ? m[1].trim() : file.basename;
	}

	private estimateSentiment(content: string): number {
		// Simple lexicon-based estimation, bounded [-1, 1]
		const positive = ['good','great','love','excellent','happy','win','success','benefit','ideal','clear'];
		const negative = ['bad','sad','hate','terrible','angry','lose','failure','problem','worse','unclear'];
		const lc = content.toLowerCase();
		let score = 0;
		for (const p of positive) if (lc.includes(p)) score += 1;
		for (const n of negative) if (lc.includes(n)) score -= 1;
		return Math.max(-1, Math.min(1, score / 10));
	}

	async search(query: string, settings?: Partial<InsightsSettings>): Promise<SearchResult[]> {
		const effective = { ...DEFAULT_INSIGHTS_SETTINGS, ...this.settings, ...settings } as InsightsSettings;
		const qTokens = tokenize(query);
		if (qTokens.length === 0) return [];

		// build query vector (tf-idf in corpus space)
		const qCounts: Record<string, number> = {};
		for (const t of qTokens) qCounts[t] = (qCounts[t] || 0) + 1;
		const qTotal = qTokens.length;
		const qVec: TfIdfVector = {};
		for (const [t, c] of Object.entries(qCounts)) {
			const tf = c / qTotal;
			const df = this.snapshot.tokenStats[t]?.documentFrequency || 0;
			const idf = Math.log((1 + this.snapshot.totalDocuments) / (1 + df)) + 1;
			qVec[t] = tf * idf;
		}

		// candidate docs via union of postings
		const candidatePaths = new Set<string>();
		for (const t of Object.keys(qVec)) {
			const postings = this.snapshot.inverted[t];
			if (!postings) continue;
			for (const p of postings) candidatePaths.add(p.documentPath);
		}

		const now = Date.now();
		const results: SearchResult[] = [];
		for (const path of candidatePaths) {
			const doc = this.snapshot.documents[path];
			if (!doc) continue;
			const sim = this.cosineSimilarity(qVec, doc.vector);

			const recencyBoost = this.recencyWeight(now - doc.meta.modifiedEpochMs, effective.recencyHalfLifeDays);
			const sentimentBoost = 1 + (doc.meta.sentimentScore * 0.1);
			const score = sim * recencyBoost * sentimentBoost;

			results.push({
				filePath: path,
				title: doc.meta.title,
				excerpt: await this.buildExcerpt(path, Object.keys(qVec)),
				score,
				similarity: sim,
				recencyBoost,
				sentimentBoost,
			});
		}

		results.sort((a, b) => b.score - a.score);
		return results.slice(0, effective.maxSearchResults);
	}

	private cosineSimilarity(a: TfIdfVector, b: TfIdfVector): number {
		let dot = 0; let na = 0; let nb = 0;
		for (const [k, av] of Object.entries(a)) {
			const bv = b[k] || 0;
			dot += av * bv;
			na += av * av;
		}
		for (const bv of Object.values(b)) nb += bv * bv;
		if (na === 0 || nb === 0) return 0;
		return dot / (Math.sqrt(na) * Math.sqrt(nb));
	}

	private recencyWeight(ageMs: number, halfLifeDays: number): number {
		const halfLifeMs = halfLifeDays * 24 * 60 * 60 * 1000;
		// exponential decay scaling in [0.5, 1.5]
		const decay = Math.pow(0.5, ageMs / halfLifeMs);
		return 0.5 + decay; // ranges (0.5, 1.5]
	}

	private async buildExcerpt(path: string, queryTokens: string[]): Promise<string> {
		try {
			const file = this.app.vault.getAbstractFileByPath(path);
			if (!(file instanceof TFile)) return '';
			const content = await this.app.vault.cachedRead(file);
			const lines = content.split(/\r?\n/);
			for (const line of lines) {
				const lc = line.toLowerCase();
				if (queryTokens.some(t => lc.includes(t))) {
					return line.trim().slice(0, 240);
				}
			}
			return lines[0]?.trim().slice(0, 240) || '';
		} catch {
			return '';
		}
	}
}