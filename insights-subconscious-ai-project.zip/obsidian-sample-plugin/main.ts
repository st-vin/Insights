import { App, Editor, MarkdownView, Modal, Notice, Plugin, PluginSettingTab, Setting, TFile, WorkspaceLeaf } from 'obsidian';
import { InsightsSettingTab } from './settings';
import { DEFAULT_INSIGHTS_SETTINGS, InsightsSettings } from './types';
import { VaultIndexer } from './indexer';
import { InsightsView, VIEW_TYPE_INSIGHTS } from './view';

export default class InsightsPlugin extends Plugin {
	settings: InsightsSettings;
	indexer: VaultIndexer;

	async onload() {
		await this.loadSettings();

		this.indexer = new VaultIndexer(this.app, this.settings);

		if (this.settings.indexOnStartup) {
			this.app.workspace.onLayoutReady(async () => {
				new Notice('INSIGHTS: Indexing vault…');
				await this.indexer.indexAllMarkdown();
				new Notice('INSIGHTS: Indexing complete');
			});
		}

		// Register view
		this.registerView(VIEW_TYPE_INSIGHTS, (leaf) => new InsightsView(leaf, this.indexer));
		this.addRibbonIcon('search', 'Open Insights', () => this.activateView());

		// Commands
		this.addCommand({
			id: 'insights-open-view',
			name: 'Open Insights view',
			callback: () => this.activateView(),
		});
		this.addCommand({
			id: 'insights-reindex',
			name: 'Rebuild index',
			callback: async () => {
				new Notice('INSIGHTS: Rebuilding index…');
				await this.indexer.indexAllMarkdown();
				new Notice('INSIGHTS: Index rebuild complete');
			},
		});

		// File change hooks
		if (this.settings.autoUpdateOnFileChange) {
			this.registerEvent(this.app.vault.on('modify', async (file) => {
				if (file instanceof TFile && file.extension === 'md') {
					await this.indexer.indexAllMarkdown();
				}
			}));
			this.registerEvent(this.app.vault.on('create', async (file) => {
				if (file instanceof TFile && file.extension === 'md') {
					await this.indexer.indexAllMarkdown();
				}
			}));
			this.registerEvent(this.app.vault.on('delete', async () => {
				await this.indexer.indexAllMarkdown();
			}));
		}

		this.addSettingTab(new InsightsSettingTab(this.app, this));
	}

	onunload() {
		// nothing special
	}

	async loadSettings() {
		this.settings = Object.assign({}, DEFAULT_INSIGHTS_SETTINGS, await this.loadData());
	}

	async saveSettings() {
		await this.saveData(this.settings);
	}

	private async activateView() {
		const { workspace } = this.app;
		let leaf = workspace.getLeavesOfType(VIEW_TYPE_INSIGHTS)[0];
		if (!leaf) {
			const right = workspace.getRightLeaf(false);
			if (right) {
				leaf = right;
				await leaf.setViewState({ type: VIEW_TYPE_INSIGHTS, active: true });
			}
		}
		if (leaf) workspace.revealLeaf(leaf);
	}
}
