import { ItemView, WorkspaceLeaf, setIcon } from 'obsidian';
import { VaultIndexer } from './indexer';
import { SearchResult } from './types';

export const VIEW_TYPE_INSIGHTS = 'insights-subconscious-ai-view';

export class InsightsView extends ItemView {
	private indexer: VaultIndexer;
	private searchInputEl: HTMLInputElement;
	private resultsEl: HTMLDivElement;

	constructor(leaf: WorkspaceLeaf, indexer: VaultIndexer) {
		super(leaf);
		this.indexer = indexer;
	}

	getViewType(): string { return VIEW_TYPE_INSIGHTS; }
	getDisplayText(): string { return 'Insights – Subconscious AI'; }
	getIcon(): string { return 'search'; }

	async onOpen(): Promise<void> {
		const container = this.containerEl.children[1] as HTMLDivElement;
		container.empty();
		container.addClass('insights-view');

		const header = container.createDiv({ cls: 'insights-header' });
		header.createEl('h3', { text: 'INSIGHTS – Subconscious AI' });
		const inputWrap = header.createDiv({ cls: 'insights-input-wrap' });
		this.searchInputEl = inputWrap.createEl('input', { type: 'text', placeholder: 'Ask across your vault…' });
		const button = inputWrap.createEl('button', { text: 'Search' });
		setIcon(button, 'search');
		button.addEventListener('click', () => this.runSearch());
		this.searchInputEl.addEventListener('keydown', (e) => {
			if (e.key === 'Enter') this.runSearch();
		});

		this.resultsEl = container.createDiv({ cls: 'insights-results' });
		this.resultsEl.createEl('div', { text: 'Type a query and press Enter.' });
	}

	private async runSearch(): Promise<void> {
		const q = this.searchInputEl.value.trim();
		if (!q) return;
		this.resultsEl.empty();
		this.resultsEl.createEl('div', { text: 'Searching…' });
		const results = await this.indexer.search(q);
		this.renderResults(results);
	}

	private renderResults(results: SearchResult[]): void {
		this.resultsEl.empty();
		if (results.length === 0) {
			this.resultsEl.createEl('div', { text: 'No results.' });
			return;
		}
		for (const r of results) {
			const card = this.resultsEl.createDiv({ cls: 'insights-result' });
			const title = card.createEl('div', { cls: 'insights-title', text: r.title });
			title.addEventListener('click', () => this.app.workspace.openLinkText(r.filePath, r.filePath));
			card.createEl('div', { cls: 'insights-excerpt', text: r.excerpt });
			const meta = card.createDiv({ cls: 'insights-meta' });
			meta.createSpan({ text: `score: ${r.score.toFixed(3)}` });
			meta.createSpan({ text: ` sim: ${r.similarity.toFixed(3)}` });
			meta.createSpan({ text: ` recency: ${r.recencyBoost.toFixed(2)}` });
			meta.createSpan({ text: ` sentiment: ${r.sentimentBoost.toFixed(2)}` });
		}
	}
}