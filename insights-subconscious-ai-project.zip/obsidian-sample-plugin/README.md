# INSIGHTS – SUBCONSCIOUS AI for Obsidian

An Obsidian plugin that emulates a tiny “subconscious” for your notes. It crawls your vault, builds a compact search index, computes light-weight embeddings, and lets you ask semantic questions to discover patterns, connections, and insights across all your notes.

## Why this exists (Philosophy)

Your Obsidian vault already contains your ideas, reflections, and references—but most of them stay buried. INSIGHTS acts like a subconscious: it continuously “notices” what’s in your notes and surfaces relevant pieces when you ask. Instead of scrolling and skimming, you can:

- Ask natural questions and get relevant passages fast
- See related notes ranked by similarity, recency, and sentiment
- Use semantic signals instead of exact keyword matches

The goal is not to replace your thinking, but to support it: reduce friction, reveal connections, and accelerate creative reasoning—privately, inside your local vault.

## What it does (Mechanics)

1. Crawling: Recursively traverses your vault’s Markdown files
2. Indexing: Tokenizes and builds an inverted index plus TF‑IDF vectors
3. Embedding: Uses local TF‑IDF (default). Optionally add external providers later
4. Ranking: Combines cosine similarity with recency and a light sentiment heuristic
5. Semantic Search: Interprets your query beyond exact keywords
6. User Interaction: A dedicated “Insights” view to ask questions and open results

## Quick Start

- Requirements: Node.js ≥ 16
- Install dependencies in this repo: `npm i`
- Start dev build (watches for changes): `npm run dev`
- Or production build: `npm run build`
- Install into your vault:
  - Create folder: `<YourVault>/.obsidian/plugins/insights-subconscious-ai`
  - Copy build artifacts: `manifest.json`, `main.js`, `styles.css` into that folder
  - In Obsidian: Settings → Community plugins → Turn on “INSIGHTS – SUBCONSCIOUS AI”

## Using the plugin

- Open the Insights view: left ribbon icon with a search icon, or Command Palette → “Open Insights view”
- Type a question or keywords, press Enter
- Click a result’s title to open the note
- Rebuild the index anytime via Command Palette → “Rebuild index”

## Settings

- Embedding provider: “TF‑IDF (local, private)” is the default
- OpenAI API key: reserved for a future external embedding option; stored locally
- Index on startup: build the index when Obsidian loads
- Auto-update on file change: re-index when files are created/modified/deleted
- Recency half-life (days): controls how much recent edits influence ranking
- Max search results: limit for results shown in the view

## How it works (Architecture)

- Tokenization (`tokenize.ts`):
  - Strips Markdown noise, lowercases, removes common stop words
  - Applies light lemmatization (e.g., “studies” → “study”, “running” → “run”)

- Indexer (`indexer.ts`):
  - Crawls all Markdown files
  - Builds term counts, then TF‑IDF vectors per document
  - Creates an inverted index for fast candidate retrieval
  - Stores document metadata (title, modified time, word count, sentiment estimate)
  - Search pipeline:
    - Tokenize query → TF‑IDF query vector
    - Retrieve candidate docs via union of postings
    - Rank by cosine similarity × recency boost × sentiment boost

- View (`view.ts`):
  - An Obsidian view with a query box and results list
  - Clicking a result opens the corresponding note

- Plugin (`main.ts`):
  - Loads settings, builds the index (on startup if enabled)
  - Registers the Insights view, ribbon icon, and commands
  - Listens to file changes to keep the index fresh

- Types (`types.ts`): shared interfaces and settings

## Privacy

- All processing happens locally in your Obsidian environment.
- No network calls are made by default. If/when external embeddings are added, you’ll opt-in and provide your own API key.

## Limitations and roadmap

- Embeddings: Currently uses TF‑IDF. External transformer-based embeddings are planned as an optional provider.
- Sentiment: A simple lexicon heuristic; non-English vaults may see mixed results.
- Performance: For very large vaults, initial indexing can take time. Caching and incremental updates are planned.

## Troubleshooting

- The Insights view shows no results
  - Make sure there are Markdown files in the vault
  - Try Command Palette → “Rebuild index”

- TypeScript build errors
  - Ensure Node.js ≥ 16
  - Run `npm i` to install dependencies
  - Use `npm run dev` for watch mode to see errors inline

- Styles don’t apply
  - Confirm `styles.css` is copied to the plugin folder next to `manifest.json` and `main.js`

## Contributing

Issues and PRs are welcome. Keep the code simple, readable, and local-first. For new embedding providers, gate all network usage behind explicit user settings and keys.

## License

MIT
