import { App, PluginSettingTab, Setting } from 'obsidian';
import { DEFAULT_INSIGHTS_SETTINGS, EmbeddingProviderType, InsightsSettings } from './types';
import type InsightsPlugin from './main';

export class InsightsSettingTab extends PluginSettingTab {
	plugin: InsightsPlugin;

	constructor(app: App, plugin: InsightsPlugin) {
		super(app, plugin);
		this.plugin = plugin;
	}

	display(): void {
		const { containerEl } = this;
		containerEl.empty();

		containerEl.createEl('h2', { text: 'INSIGHTS – Subconscious AI' });

		new Setting(containerEl)
			.setName('Embedding provider')
			.setDesc('Choose the vectorization method for semantic search.')
			.addDropdown(drop => drop
				.addOption('tfidf-local', 'TF‑IDF (local, private)')
				.addOption('openai', 'OpenAI Embeddings (requires API key)')
				.setValue(this.plugin.settings.provider)
				.onChange(async (value: EmbeddingProviderType) => {
					this.plugin.settings.provider = value;
					await this.plugin.saveSettings();
				}));

		new Setting(containerEl)
			.setName('OpenAI API Key')
			.setDesc('Stored locally. Only needed if OpenAI provider is selected.')
			.addText(text => text
				.setPlaceholder('sk-...')
				.setValue(this.plugin.settings.openAIApiKey)
				.onChange(async (value) => {
					this.plugin.settings.openAIApiKey = value.trim();
					await this.plugin.saveSettings();
				}));

		new Setting(containerEl)
			.setName('Index on startup')
			.setDesc('Build the index when Obsidian loads')
			.addToggle(toggle => toggle
				.setValue(this.plugin.settings.indexOnStartup)
				.onChange(async (value) => {
					this.plugin.settings.indexOnStartup = value;
					await this.plugin.saveSettings();
				}));

		new Setting(containerEl)
			.setName('Auto-update on file change')
			.setDesc('Update index when files are created/modified/renamed')
			.addToggle(toggle => toggle
				.setValue(this.plugin.settings.autoUpdateOnFileChange)
				.onChange(async (value) => {
					this.plugin.settings.autoUpdateOnFileChange = value;
					await this.plugin.saveSettings();
				}));

		new Setting(containerEl)
			.setName('Recency half-life (days)')
			.setDesc('Higher values reduce recency emphasis in ranking')
			.addText(text => text
				.setPlaceholder('30')
				.setValue(String(this.plugin.settings.recencyHalfLifeDays))
				.onChange(async (value) => {
					const v = parseFloat(value);
					if (!Number.isNaN(v) && v > 0) {
						this.plugin.settings.recencyHalfLifeDays = v;
						await this.plugin.saveSettings();
					}
				}));

		new Setting(containerEl)
			.setName('Max search results')
			.setDesc('Limit the number of results shown in the insights view')
			.addText(text => text
				.setPlaceholder('20')
				.setValue(String(this.plugin.settings.maxSearchResults))
				.onChange(async (value) => {
					const v = parseInt(value);
					if (!Number.isNaN(v) && v > 0) {
						this.plugin.settings.maxSearchResults = v;
						await this.plugin.saveSettings();
					}
				}));
	}
}