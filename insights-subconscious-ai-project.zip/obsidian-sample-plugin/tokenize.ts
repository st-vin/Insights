const STOP_WORDS = new Set([
	'a', 'an', 'the', 'and', 'or', 'but', 'if', 'then', 'else', 'when', 'at', 'by', 'for', 'with', 'about', 'against', 'between', 'into', 'through', 'during', 'before', 'after', 'above', 'below', 'to', 'from', 'up', 'down', 'in', 'out', 'on', 'off', 'over', 'under', 'again', 'further', 'once', 'here', 'there', 'all', 'any', 'both', 'each', 'few', 'more', 'most', 'other', 'some', 'such', 'no', 'nor', 'not', 'only', 'own', 'same', 'so', 'than', 'too', 'very'
]);

function stripMarkdown(text: string): string {
	return text
		.replace(/`{3}[\s\S]*?`{3}/g, ' ')
		.replace(/`[^`]*`/g, ' ')
		.replace(/!\[[^\]]*\]\([^\)]*\)/g, ' ')
		.replace(/\[[^\]]*\]\([^\)]*\)/g, ' ')
		.replace(/^>.*$/gm, ' ')
		.replace(/^#{1,6}\s.*$/gm, ' ')
		.replace(/[*_~#>\-]+/g, ' ');
}

function basicLemma(token: string): string {
	// Very light stemming rules
	let t = token;
	if (t.endsWith('ies') && t.length > 4) return t.slice(0, -3) + 'y';
	if (t.endsWith('ing') && t.length > 5) return t.slice(0, -3);
	if (t.endsWith('ed') && t.length > 4) return t.slice(0, -2);
	if (t.endsWith('s') && t.length > 3) return t.slice(0, -1);
	return t;
}

export function tokenize(content: string): string[] {
	const clean = stripMarkdown(content.toLowerCase());
	const raw = clean.split(/[^a-z0-9]+/g).filter(Boolean);
	const tokens: string[] = [];
	for (const r of raw) {
		if (STOP_WORDS.has(r)) continue;
		const lemma = basicLemma(r);
		if (lemma.length <= 1) continue;
		tokens.push(lemma);
	}
	return tokens;
}